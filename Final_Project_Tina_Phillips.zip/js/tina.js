// Initialize Firebase
  var config = {
    apiKey: "AIzaSyCF4kEUuZue6Uw-uDx_EDjnHnWsjI2nDEg",
    authDomain: "final-project-tina-phillips.firebaseapp.com",
    databaseURL: "https://final-project-tina-phillips.firebaseio.com",
    storageBucket: "final-project-tina-phillips.appspot.com",
    messagingSenderId: "324874523421"
  };
  firebase.initializeApp(config);

  var storage = firebase.storage();